<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Asignatura;

class AsignaturaFactory extends Factory
{
    protected $model = Asignatura:: class;
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'codigo_asignatura' => $this->faker -> word(),      
            'requisito'=> $this->faker -> word()
        ];
    }
}
